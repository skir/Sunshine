Sunshine
========

Sunshine is the companion Android app for the Udacity course [Developing Android Apps: Android Fundamentals](https://www.udacity.com/course/ud853).

Take the course to find out how to build this app a step at a time, and eventually create your own Android App!
